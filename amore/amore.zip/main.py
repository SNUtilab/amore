# -*- coding: utf-8 -*-
"""
Created on Sun Feb 13 16:33:33 2022

@author: tkdgu
"""

if __name__ == '__main__':
    
    import os
    import sys
    import pickle
    import pandas as pd
    
    directory = os.path.dirname(os.path.abspath(__file__))
    directory = directory.replace("\\", "/") # window
    os.chdir(directory)    
    
    sys.path.append(directory+'/submodule')

    directory = 'D:/아주대학교/tmlab - 문서/프로젝트/2021/아모레퍼시픽/데이터/제조/테스트/'

    data = pd.DataFrame()
    
    for file in os.listdir(directory) :
        
        temp_data = pd.read_csv(directory + file, skiprows=4)
        data = pd.concat([data, temp_data]).reset_index(drop = 1)
    
    #%% 1. 데이터 전처리
    
    data_ = pd.DataFrame()
    
    for idx, row in data.iterrows() : 
        code_list = ['CN', 'US', 'EP']
        if any(code in row['번호'] for code in code_list):
            
            state_list = ['Rejected', 'Withdrawn' , 'Abandoned']
            
            if any(state == row['최종 상태'] for state in state_list):
                pass
            else : 
                data_ = data_.append(row)
        
    
    # 데이터 추출
    # 전체 데이터 13만개 
    
    data_ = data_[['번호','명칭','요약', '출원인대표명', '국제특허분류', '공통특허분류', '출원일','독립 청구항수', '전체 청구항수',
                 '대표 청구항','자국인용횟수', '자국피인용횟수' ,'INPADOC패밀리국가수','발명자수']]
    
    data_.columns = ['pt_id', 'title', 'abstract', 'applicant', 'IPC', 'CPC', 'application_date', 'ind_claims_cnt', 'total_claims_cnt',
                    'claims_rep', 'forward_cites_cnt', 'backward_cites_cnt', 'family_country_cnt', 'inventor_cnt']    
    
    data_ = data_[['pt_id','title','abstract','CPC','application_date','claims_rep']]
    data_['application_year'] = data_['application_date'].apply(lambda x : x.split('.')[0])

    data_['TA'] = data_['title'] +' '+ data_['abstract']
    
    # 시계열 처리
    span_dict = {}
    span_dict['2015'] = 0
    span_dict['2016'] = 0
    span_dict['2017'] = 1
    span_dict['2018'] = 1
    span_dict['2019'] = 2
    span_dict['2020'] = 2
    span_dict['2021'] = 2
    
    data_['application_span'] = data_['application_year'].apply(lambda x : span_dict[x])
    
    #%% 2. 텍스트마이닝 및  lda 준비 
    
    # text preprocess
    from nltk.corpus import stopwords
    import spacy
    import re
    from collections import Counter
    import numpy as np 
    
    nlp = spacy.load("en_core_web_sm")
    nlp.enable_pipe("senter")
    stopwords_nltk = set(stopwords.words('english'))
    stopwords_spacy = nlp.Defaults.stop_words
    stopwords_add = ['method', 'invention', 'comprise', 'use', 'provide', 'present'
                     ,'relate', 'thereof', 'include', 'contain', 'disclose', 'effect']

    def preprocess_text(df, col) :
        
        # download('en_core_web_sm')
        
        # stopwords_.append('-PRON-')
        
        col_ = col + '_wordlist'
        df[col_] = [nlp(i) for i in df[col]]
        
        print('nlp finished')
        
        # get keyword
        df[col_] = [[token.lemma_.lower() for token in doc] for doc in df[col_]] # lemma
        df[col_] = [[token for token in doc if len(token) > 2] for doc in df[col_]] # 길이기반 제거
        df[col_] = [[re.sub(r"[^a-zA-Z0-9-]","",token) for token in doc ] for doc in df[col_]] #특수문자 교체    
        df[col_] = [[token for token in doc if not token.isdigit() ] for doc in df[col_]]  #숫자제거 
        df[col_] = [[token for token in doc if len(token) > 2] for doc in df[col_]] # 길이기반 제거
        df[col_] = [[token for token in doc if token not in stopwords_nltk] for doc in df[col_]] # 길이기반 제거
        df[col_] = [[token for token in doc if token not in stopwords_spacy] for doc in df[col_]] # 길이기반 제거
        df[col_] = [[token for token in doc if token not in stopwords_add] for doc in df[col_]] # 길이기반 제거
        
        return(df)
    
    # TF-IDF
    def tf_idf_counter(word_list) :
        temp = sum(word_list , [])
        c = Counter(temp)
        counter = pd.DataFrame(c.items())
        counter = counter.sort_values(1, ascending=False).reset_index(drop = 1)
        counter.columns = ['term', 'tf']
        counter = counter[counter['tf'] >= 10]
        counter['df'] = 0
        
        for idx,row in counter.iterrows() :
            term = row['term']
            for temp_list in word_list :
                if term in temp_list : counter['df'][idx] +=1
        
        counter['tf-idf'] = counter['tf'] / np.sqrt((1+ counter['df']))
        counter = counter.sort_values('tf-idf', ascending=False).reset_index(drop = 1)
        #counter = counter.loc[counter['tf-idf'] >= 1.5 , :].reset_index(drop = 1)
        
        return(counter)
    
    
    data_ = preprocess_text(data_, 'TA')
    c = Counter(sum(data_['TA_wordlist'] , []))
    tf_idf = tf_idf_counter(data_['TA_wordlist'])
    
    #%% 3. LDA tunning
    
    from gensim.corpora import Dictionary
    import LDA_tunning
    import LDA_handling
    
    # with open('./output/LDA_result.pickle', 'rb') as f:
    #     LDA_obj = pickle.load(f)

    texts = data_['TA_wordlist']

    keyword_dct = Dictionary(texts)
    keyword_dct.filter_extremes(no_below = 3)
    keyword_list = list(keyword_dct.token2id.keys())

    corpus = [keyword_dct.doc2bow(text) for text in texts]
    # encoded_keyword = embedding.keyword_embedding(keyword_list)
    texts = [[k for k in doc if k in keyword_list] for doc in texts]
    docs = [" ".join(i) for i in texts]
    
    LDA_obj = LDA_tunning.tunning(texts, keyword_dct, corpus)
    
    
    #%% 4. LDA handling
    
    LDA_obj = LDA_tunning.LDA_obj(texts, 20, 1,0.01) # best score 입력
    # import pickle
    # with open('./output/LDA_result.pickle', 'wb') as f:
    #     pickle.dump(LDA_obj, f, pickle.HIGHEST_PROTOCOL)

    
    
    topic_doc_df = LDA_handling.get_topic_doc(LDA_obj.model, LDA_obj.corpus)
    topic_word_df = LDA_handling.get_topic_word_matrix(LDA_obj.model)
    topic_topword_df = LDA_handling.get_topic_topword_matrix(LDA_obj.model, 20)
    # topic_time_df =  LDA_handling.get_topic_vol_time(LDA_obj.model, topic_doc_df, data_sample, 'time')
    topic_title_df = LDA_handling.get_most_similar_doc2topic(data, topic_doc_df)
    volumn_dict = LDA_handling.get_topic_vol(LDA_obj.model, LDA_obj.corpus)
    